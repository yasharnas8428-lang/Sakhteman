using BuildingManager.Data;
using System.Globalization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// دیتابیس کنار فایل‌های برنامه ذخیره می‌شود (مستقل از پوشه‌ای که برنامه از آن اجرا می‌شود)
var dbPath = Path.Combine(builder.Environment.ContentRootPath, "BuildingManager.db");
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite($"Data Source={dbPath}"));

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromDays(7);
        options.SlidingExpiration = true;
    });

builder.Services.AddAuthorization();

var app = builder.Build();

// دانلود یک‌باره فایل‌های بوت‌استرپ/jQuery/فونت (فقط اگر هنوز در wwwroot/lib نیستند)
await BuildingManager.Helpers.LibraryDownloader.EnsureAsync(app.Environment.WebRootPath, app.Logger);

// ساخت خودکار دیتابیس (SQLite) در اولین اجرا
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

// فرمت اعداد اعشاری (مثل متراژ ۸۵.۵) مستقل از زبان ویندوز کار کند
var invariant = CultureInfo.InvariantCulture;
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(invariant),
    SupportedCultures = new List<CultureInfo> { invariant },
    SupportedUICultures = new List<CultureInfo> { invariant }
});

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
