namespace BuildingManager.Helpers;

/// <summary>
/// برنامه برای کار روی اینترنت ملی نباید به CDN خارجی وابسته باشد.
/// بار اول که پروژه را روی کامپیوتر خودتان (با اینترنت) اجرا می‌کنید، فایل‌های بوت‌استرپ، jQuery و فونت
/// داخل wwwroot/lib دانلود می‌شوند و از آن به بعد همه چیز از خود برنامه لود می‌شود.
/// </summary>
public static class LibraryDownloader
{
    private static readonly (string Path, string[] Urls)[] Files =
    {
        ("lib/bootstrap/bootstrap.rtl.min.css", new[] {
            "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css",
            "https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.rtl.min.css",
            "https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" }),
        ("lib/bootstrap/bootstrap.bundle.min.js", new[] {
            "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js",
            "https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js",
            "https://unpkg.com/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" }),
        ("lib/jquery/jquery.min.js", new[] {
            "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js",
            "https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js",
            "https://unpkg.com/jquery@3.7.1/dist/jquery.min.js" }),
        ("lib/jquery/jquery.validate.min.js", new[] {
            "https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js",
            "https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js",
            "https://unpkg.com/jquery-validation@1.19.5/dist/jquery.validate.min.js" }),
        ("lib/jquery/jquery.validate.unobtrusive.min.js", new[] {
            "https://cdnjs.cloudflare.com/ajax/libs/jquery-validation-unobtrusive/4.0.0/jquery.validate.unobtrusive.min.js",
            "https://cdn.jsdelivr.net/npm/jquery-validation-unobtrusive@4.0.0/dist/jquery.validate.unobtrusive.min.js",
            "https://unpkg.com/jquery-validation-unobtrusive@4.0.0/dist/jquery.validate.unobtrusive.min.js" }),
        ("lib/fonts/Vazirmatn.woff2", new[] {
            "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.0.3/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2",
            "https://cdn.jsdelivr.net/npm/vazirmatn@33.0.3/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2",
            "https://unpkg.com/vazirmatn@33.0.3/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2" }),
    };

    public static async Task EnsureAsync(string? webRoot, ILogger logger)
    {
        if (string.IsNullOrEmpty(webRoot)) return;

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(90));
        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };

        foreach (var (rel, urls) in Files)
        {
            var full = Path.Combine(webRoot, rel.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(full) && new FileInfo(full).Length > 0) continue;

            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            var ok = false;
            foreach (var url in urls)
            {
                try
                {
                    var bytes = await http.GetByteArrayAsync(url, cts.Token);
                    if (bytes.Length == 0) continue;
                    await File.WriteAllBytesAsync(full, bytes, cts.Token);
                    logger.LogInformation("Downloaded {File}", rel);
                    ok = true;
                    break;
                }
                catch (Exception ex)
                {
                    logger.LogWarning("Could not download {Url}: {Message}", url, ex.Message);
                }
            }
            if (!ok)
                logger.LogError("فایل {File} دانلود نشد. راهنمای wwwroot/lib/README.txt را ببینید.", rel);
        }
    }
}
