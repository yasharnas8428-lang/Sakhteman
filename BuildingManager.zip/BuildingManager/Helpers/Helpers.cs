using System.Globalization;
using System.Text;
using BuildingManager.Models;
using System.Security.Cryptography;

namespace BuildingManager.Helpers;

public static class PasswordHelper
{
    private const int Iterations = 100_000;

    public static string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);
        return $"{Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    public static bool Verify(string password, string stored)
    {
        var parts = stored.Split('.');
        if (parts.Length != 3 || !int.TryParse(parts[0], out var iterations)) return false;
        var salt = Convert.FromBase64String(parts[1]);
        var expected = Convert.FromBase64String(parts[2]);
        var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expected.Length);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }
}

public static class Formatters
{
    private static readonly PersianCalendar Pc = new();

    public static string ToShamsi(this DateTime d)
        => $"{Pc.GetYear(d):0000}/{Pc.GetMonth(d):00}/{Pc.GetDayOfMonth(d):00}";

    public static string ToShamsi(this DateTime? d) => d.HasValue ? d.Value.ToShamsi() : "-";

    public static string ToToman(this long amount)
        => amount.ToString("N0", CultureInfo.InvariantCulture) + " تومان";
}

public static class DigitHelper
{
    public static string ToEnglishDigits(string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (var ch in s)
        {
            if (ch >= '۰' && ch <= '۹') sb.Append((char)('0' + (ch - '۰')));
            else if (ch >= '٠' && ch <= '٩') sb.Append((char)('0' + (ch - '٠')));
            else sb.Append(ch);
        }
        return sb.ToString();
    }
}

public static class CardHelper
{
    public static bool TryNormalize(string? input, out string card)
    {
        card = "";
        if (string.IsNullOrWhiteSpace(input)) return false;
        var s = DigitHelper.ToEnglishDigits(input);
        s = new string(s.Where(ch => ch != ' ' && ch != '-' && ch != '_').ToArray());
        if (s.Length != 16 || !s.All(char.IsAsciiDigit)) return false;
        card = s;
        return true;
    }

    public static string Format(string? card)
        => card is { Length: 16 } ? $"{card[..4]} {card[4..8]} {card[8..12]} {card[12..]}" : card ?? "";
}

public static class EnumLabels
{
    public static string Label(this SplitMethod m) => m == SplitMethod.ByArea ? "بر اساس متراژ" : "مساوی بین واحدها";
    public static string Label(this PayerType p) => p == PayerType.Owner ? "مالک" : "ساکن";
}

public static class ChargeRules
{
    // اگر هزینه بر عهده «مالک» باشد، فقط وقتی ساکن خودش مالک است باید پرداخت کند
    public static bool PayableBy(Resident r, Expense e) => e.PayerType == PayerType.Occupant || r.IsOwner;
}
