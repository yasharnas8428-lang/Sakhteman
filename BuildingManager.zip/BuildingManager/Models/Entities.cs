using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BuildingManager.Models;

public enum SplitMethod { Equal = 0, ByArea = 1 }

public enum PayerType { Occupant = 0, Owner = 1 }

public static class Roles
{
    public const string Manager = "Manager";
    public const string Resident = "Resident";
}

public class AppUser
{
    public int Id { get; set; }
    [Required, MaxLength(50)] public string Username { get; set; } = "";
    [Required] public string PasswordHash { get; set; } = "";
    [Required, MaxLength(100)] public string FullName { get; set; } = "";
    [MaxLength(20)] public string? CardNumber { get; set; }
    [MaxLength(100)] public string? CardHolderName { get; set; }
    [Required, MaxLength(20)] public string Role { get; set; } = Roles.Resident;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}

public class Building
{
    public int Id { get; set; }
    public int ManagerId { get; set; }
    public AppUser Manager { get; set; } = null!;

    [Required, MaxLength(150)] public string Name { get; set; } = "";
    [MaxLength(300)] public string? Address { get; set; }
    public int FloorsCount { get; set; }
    public int UnitsPerFloor { get; set; }
    public int StorageCount { get; set; }
    public int ParkingCount { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    [NotMapped] public int TotalUnits => FloorsCount * UnitsPerFloor;

    public List<Unit> Units { get; set; } = new();
    public List<Resident> Residents { get; set; } = new();
    public List<Expense> Expenses { get; set; } = new();
}

public class Unit
{
    public int Id { get; set; }
    public int BuildingId { get; set; }
    public Building Building { get; set; } = null!;
    public int Floor { get; set; }
    public int Number { get; set; }
    public double? Area { get; set; }

    public Resident? Resident { get; set; }
    public List<Charge> Charges { get; set; } = new();
}

public class Resident
{
    public int Id { get; set; }
    public int BuildingId { get; set; }
    public Building Building { get; set; } = null!;
    public int UnitId { get; set; }
    public Unit Unit { get; set; } = null!;
    public int UserId { get; set; }
    public AppUser User { get; set; } = null!;

    [Required, MaxLength(100)] public string FullName { get; set; } = "";
    [Required, MaxLength(20)] public string Phone { get; set; } = "";
    [MaxLength(20)] public string? NationalId { get; set; }
    public int PersonCount { get; set; } = 1;

    public bool IsOwner { get; set; } = true;
    [MaxLength(100)] public string? OwnerFullName { get; set; }
    [MaxLength(20)] public string? OwnerPhone { get; set; }

    public int? StorageNumber { get; set; }
    public int? ParkingNumber { get; set; }
    public DateTime? MoveInDate { get; set; }
    [MaxLength(500)] public string? Notes { get; set; }
}

public class Expense
{
    public int Id { get; set; }
    public int BuildingId { get; set; }
    public Building Building { get; set; } = null!;
    [Required, MaxLength(150)] public string Title { get; set; } = "";
    [MaxLength(1000)] public string? Description { get; set; }
    public long TotalAmount { get; set; }
    public SplitMethod SplitMethod { get; set; } = SplitMethod.Equal;
    public PayerType PayerType { get; set; } = PayerType.Occupant;
    [MaxLength(300)] public string? ReceiptPath { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public List<Charge> Charges { get; set; } = new();
}

public class Charge
{
    public int Id { get; set; }
    public int ExpenseId { get; set; }
    public Expense Expense { get; set; } = null!;
    public int UnitId { get; set; }
    public Unit Unit { get; set; } = null!;
    public long Amount { get; set; }
    public bool IsPaid { get; set; }
    public DateTime? PaidAt { get; set; }
}
