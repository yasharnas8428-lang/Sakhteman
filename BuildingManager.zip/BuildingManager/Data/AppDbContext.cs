using BuildingManager.Models;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Building> Buildings => Set<Building>();
    public DbSet<Unit> Units => Set<Unit>();
    public DbSet<Resident> Residents => Set<Resident>();
    public DbSet<Expense> Expenses => Set<Expense>();
    public DbSet<Charge> Charges => Set<Charge>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<AppUser>().HasIndex(u => u.Username).IsUnique();

        b.Entity<Building>().HasOne(x => x.Manager).WithMany().HasForeignKey(x => x.ManagerId);
        b.Entity<Building>().HasIndex(x => x.ManagerId).IsUnique();

        b.Entity<Unit>().HasIndex(u => new { u.BuildingId, u.Number }).IsUnique();

        b.Entity<Resident>().HasOne(r => r.Unit).WithOne(u => u.Resident).HasForeignKey<Resident>(r => r.UnitId);
        b.Entity<Resident>().HasOne(r => r.User).WithOne().HasForeignKey<Resident>(r => r.UserId);
        b.Entity<Resident>().HasOne(r => r.Building).WithMany(x => x.Residents).HasForeignKey(r => r.BuildingId);

        // جلوگیری از حذف زنجیره‌ای ناخواسته
        foreach (var fk in b.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            fk.DeleteBehavior = DeleteBehavior.Restrict;

        // با حذف هزینه، سهم واحدها هم حذف می‌شود
        b.Entity<Charge>().HasOne(c => c.Expense).WithMany(e => e.Charges)
            .HasForeignKey(c => c.ExpenseId).OnDelete(DeleteBehavior.Cascade);
    }
}
