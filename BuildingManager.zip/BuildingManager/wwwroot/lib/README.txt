این پوشه خودکار پر می‌شود (بار اول اجرا با اینترنت آزاد/VPN).
اگر خودکار دانلود نشد، فایل‌های زیر را دستی دانلود و با همین نام و مسیر اینجا بگذارید:

lib/bootstrap/bootstrap.rtl.min.css          <- bootstrap 5.3.3 (dist/css/bootstrap.rtl.min.css)
lib/bootstrap/bootstrap.bundle.min.js        <- bootstrap 5.3.3 (dist/js/bootstrap.bundle.min.js)
lib/jquery/jquery.min.js                     <- jquery 3.7.1
lib/jquery/jquery.validate.min.js            <- jquery-validation 1.19.5
lib/jquery/jquery.validate.unobtrusive.min.js<- jquery-validation-unobtrusive 4.0.0
lib/fonts/Vazirmatn.woff2                    <- Vazirmatn variable font (Vazirmatn[wght].woff2)

مثال دانلود: https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css
(بعد از اینکه یک بار پر شد، پروژه را Publish کنید؛ سرور داخلی دیگر نیازی به اینترنت خارجی ندارد.)
