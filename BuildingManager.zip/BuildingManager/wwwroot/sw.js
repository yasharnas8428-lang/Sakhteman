// Service Worker ساده: فایل‌های ثابت کش می‌شوند، صفحات همیشه از سرور گرفته می‌شوند (اطلاعات مالی همیشه تازه باشد)
const CACHE = 'building-manager-v1';
const PRECACHE = ['/offline.html', '/css/site.css', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // صفحات: همیشه از شبکه؛ اگر آفلاین بود صفحه آفلاین
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).catch(() => caches.match('/offline.html')));
    return;
  }

  // آپلودها و سایر مسیرهای پویا کش نمی‌شوند
  if (url.pathname.startsWith('/uploads/')) return;

  // فایل‌های ثابت: اول کش، همزمان به‌روزرسانی
  const isStatic = /\.(css|js|png|jpg|svg|ico|webmanifest|woff2?)$/i.test(url.pathname);
  if (isStatic) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fresh = fetch(req).then((res) => {
          if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
          return res;
        }).catch(() => cached);
        return cached || fresh;
      })
    );
  }
});
