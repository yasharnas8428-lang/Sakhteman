using System.Security.Claims;
using BuildingManager.Data;
using BuildingManager.Helpers;
using BuildingManager.Models;
using BuildingManager.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Controllers;

public class AccountController(AppDbContext db) : Controller
{
    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public IActionResult Register() => View(new RegisterVM());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterVM vm)
    {
        string card = "";
        if (!string.IsNullOrWhiteSpace(vm.CardNumber) && !CardHelper.TryNormalize(vm.CardNumber, out card))
            ModelState.AddModelError(nameof(vm.CardNumber), "شماره کارت باید ۱۶ رقم باشد");

        if (!ModelState.IsValid) return View(vm);

        var username = vm.Username.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.Username == username))
        {
            ModelState.AddModelError(nameof(vm.Username), "این نام کاربری قبلاً ثبت شده است");
            return View(vm);
        }

        var user = new AppUser
        {
            Username = username,
            FullName = vm.FullName.Trim(),
            PasswordHash = PasswordHelper.Hash(vm.Password),
            Role = Roles.Manager,
            CardNumber = card,
            CardHolderName = string.IsNullOrWhiteSpace(vm.CardHolderName) ? vm.FullName.Trim() : vm.CardHolderName.Trim()
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();

        await SignInAsync(user, true);
        return RedirectToAction("Create", "Building");
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null) => View(new LoginVM { ReturnUrl = returnUrl });

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginVM vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var username = vm.Username.Trim().ToLowerInvariant();
        var user = await db.Users.FirstOrDefaultAsync(u => u.Username == username);
        if (user == null || !PasswordHelper.Verify(vm.Password, user.PasswordHash))
        {
            ModelState.AddModelError("", "نام کاربری یا رمز عبور اشتباه است");
            return View(vm);
        }

        await SignInAsync(user, vm.RememberMe);

        if (!string.IsNullOrEmpty(vm.ReturnUrl) && Url.IsLocalUrl(vm.ReturnUrl))
            return LocalRedirect(vm.ReturnUrl);

        return user.Role == Roles.Manager
            ? RedirectToAction("Index", "Building")
            : RedirectToAction("Index", "My");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "Home");
    }

    public IActionResult AccessDenied() => View();

    // ---------- حساب من (مدیر و ساکن) ----------

    [Authorize]
    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var user = await db.Users.FindAsync(CurrentUserId);
        if (user == null) return RedirectToAction(nameof(Login));

        return View(new ProfileVM
        {
            FullName = user.FullName,
            Username = user.Username,
            CardNumber = user.CardNumber,
            CardHolderName = user.CardHolderName,
            IsManager = user.Role == Roles.Manager
        });
    }

    [Authorize]
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(ProfileVM vm)
    {
        var user = await db.Users.FindAsync(CurrentUserId);
        if (user == null) return RedirectToAction(nameof(Login));

        var isManager = user.Role == Roles.Manager;
        vm.IsManager = isManager;

        string card = "";
        if (isManager)
        {
            if (string.IsNullOrWhiteSpace(vm.FullName))
                ModelState.AddModelError(nameof(vm.FullName), "نام را وارد کنید");
            if (!CardHelper.TryNormalize(vm.CardNumber, out card))
                ModelState.AddModelError(nameof(vm.CardNumber), "شماره کارت باید ۱۶ رقم باشد");
        }

        var username = (vm.Username ?? "").Trim().ToLowerInvariant();
        if (ModelState.IsValid && await db.Users.AnyAsync(u => u.Username == username && u.Id != user.Id))
            ModelState.AddModelError(nameof(vm.Username), "این نام کاربری قبلاً استفاده شده است");

        if (!ModelState.IsValid) return View(vm);

        user.Username = username;
        if (isManager)
        {
            user.FullName = vm.FullName!.Trim();
            user.CardNumber = card;
            user.CardHolderName = string.IsNullOrWhiteSpace(vm.CardHolderName) ? user.FullName : vm.CardHolderName.Trim();
        }
        await db.SaveChangesAsync();

        // اطلاعات داخل کوکی هم باید به‌روز شود
        await SignInAsync(user, true);

        TempData["Success"] = "اطلاعات حساب ذخیره شد.";
        return RedirectToAction(nameof(Profile));
    }

    [Authorize]
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangePassword(string? currentPassword, string? newPassword, string? confirmPassword)
    {
        var user = await db.Users.FindAsync(CurrentUserId);
        if (user == null) return RedirectToAction(nameof(Login));

        if (string.IsNullOrEmpty(currentPassword) || !PasswordHelper.Verify(currentPassword, user.PasswordHash))
            TempData["Error"] = "رمز عبور فعلی اشتباه است.";
        else if (string.IsNullOrEmpty(newPassword) || newPassword.Length < 6)
            TempData["Error"] = "رمز عبور جدید حداقل ۶ کاراکتر باشد.";
        else if (newPassword != confirmPassword)
            TempData["Error"] = "رمز جدید و تکرار آن یکسان نیست.";
        else
        {
            user.PasswordHash = PasswordHelper.Hash(newPassword);
            await db.SaveChangesAsync();
            TempData["Success"] = "رمز عبور تغییر کرد.";
        }
        return RedirectToAction(nameof(Profile));
    }

    private async Task SignInAsync(AppUser user, bool persistent)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Username),
            new("FullName", user.FullName),
            new(ClaimTypes.Role, user.Role)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity),
            new AuthenticationProperties { IsPersistent = persistent });
    }
}
