using BuildingManager.Data;
using BuildingManager.Models;
using BuildingManager.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Controllers;

[Authorize(Roles = Roles.Manager)]
public class BuildingController(AppDbContext db) : AppController(db)
{
    public async Task<IActionResult> Index()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction(nameof(Create));

        var residentCount = await Db.Residents.CountAsync(r => r.BuildingId == b.Id);
        var vm = new DashboardVM
        {
            Building = b,
            ResidentCount = residentCount,
            EmptyUnits = b.TotalUnits - residentCount,
            ExpenseCount = await Db.Expenses.CountAsync(e => e.BuildingId == b.Id),
            UnpaidTotal = await Db.Charges.Where(c => c.Expense.BuildingId == b.Id && !c.IsPaid).SumAsync(c => c.Amount),
            PaidTotal = await Db.Charges.Where(c => c.Expense.BuildingId == b.Id && c.IsPaid).SumAsync(c => c.Amount),
            RecentExpenses = await Db.Expenses.Where(e => e.BuildingId == b.Id)
                .OrderByDescending(e => e.CreatedAt).Take(5).ToListAsync()
        };
        return View(vm);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        if (await GetMyBuildingAsync() != null) return RedirectToAction(nameof(Index));
        return View(new BuildingCreateVM());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(BuildingCreateVM vm)
    {
        if (await GetMyBuildingAsync() != null) return RedirectToAction(nameof(Index));
        if (!ModelState.IsValid) return View(vm);

        var building = new Building
        {
            ManagerId = UserId,
            Name = vm.Name.Trim(),
            Address = vm.Address?.Trim(),
            FloorsCount = vm.FloorsCount!.Value,
            UnitsPerFloor = vm.UnitsPerFloor!.Value,
            StorageCount = vm.StorageCount,
            ParkingCount = vm.ParkingCount
        };

        // ساخت خودکار واحدها: شماره‌گذاری پشت سر هم از طبقه اول
        var number = 1;
        for (var floor = 1; floor <= building.FloorsCount; floor++)
            for (var i = 1; i <= building.UnitsPerFloor; i++)
                building.Units.Add(new Unit { Floor = floor, Number = number++ });

        Db.Buildings.Add(building);
        await Db.SaveChangesAsync();

        TempData["Success"] = $"ساختمان ثبت شد و {building.TotalUnits} واحد ساخته شد. حالا ساکنین را اضافه کنید.";
        return RedirectToAction("Index", "Residents");
    }

    [HttpGet]
    public async Task<IActionResult> Edit()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction(nameof(Create));
        return View(new BuildingEditVM
        {
            Name = b.Name, Address = b.Address, StorageCount = b.StorageCount, ParkingCount = b.ParkingCount
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(BuildingEditVM vm)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction(nameof(Create));
        if (!ModelState.IsValid) return View(vm);

        b.Name = vm.Name.Trim();
        b.Address = vm.Address?.Trim();
        b.StorageCount = vm.StorageCount;
        b.ParkingCount = vm.ParkingCount;
        await Db.SaveChangesAsync();

        TempData["Success"] = "مشخصات ساختمان ذخیره شد.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Areas()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction(nameof(Create));

        var list = await Db.Units.Include(u => u.Resident)
            .Where(u => u.BuildingId == b.Id).OrderBy(u => u.Number)
            .Select(u => new UnitAreaVM
            {
                Id = u.Id, Number = u.Number, Floor = u.Floor,
                ResidentName = u.Resident != null ? u.Resident.FullName : null,
                Area = u.Area
            }).ToListAsync();
        return View(list);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Areas(List<UnitAreaVM> items)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction(nameof(Create));

        if (!ModelState.IsValid)
        {
            TempData["Error"] = "متراژها باید بین ۵ تا ۵۰۰۰ متر باشند.";
            return RedirectToAction(nameof(Areas));
        }

        var units = await Db.Units.Where(u => u.BuildingId == b.Id).ToDictionaryAsync(u => u.Id);
        foreach (var item in items)
            if (units.TryGetValue(item.Id, out var unit))
                unit.Area = item.Area;

        await Db.SaveChangesAsync();
        TempData["Success"] = "متراژ واحدها ذخیره شد.";
        return RedirectToAction(nameof(Areas));
    }

    public async Task<IActionResult> Units()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction(nameof(Create));

        ViewBag.Building = b;
        var units = await Db.Units.Include(u => u.Resident)
            .Where(u => u.BuildingId == b.Id).OrderBy(u => u.Number).ToListAsync();
        return View(units);
    }
}
