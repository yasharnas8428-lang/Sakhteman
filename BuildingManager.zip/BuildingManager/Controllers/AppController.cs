using System.Security.Claims;
using BuildingManager.Data;
using BuildingManager.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Controllers;

public abstract class AppController(AppDbContext db) : Controller
{
    protected readonly AppDbContext Db = db;

    protected int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    protected Task<Building?> GetMyBuildingAsync()
        => Db.Buildings.FirstOrDefaultAsync(b => b.ManagerId == UserId);
}
