using BuildingManager.Data;
using BuildingManager.Models;
using BuildingManager.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Controllers;

[Authorize(Roles = Roles.Manager)]
public class ExpensesController(AppDbContext db, IWebHostEnvironment env) : AppController(db)
{
    private static readonly string[] AllowedExt = { ".jpg", ".jpeg", ".png", ".webp", ".gif", ".pdf" };
    private const long MaxReceiptBytes = 5 * 1024 * 1024;

    public async Task<IActionResult> Index()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var rows = await Db.Expenses.Where(e => e.BuildingId == b.Id)
            .OrderByDescending(e => e.CreatedAt)
            .Select(e => new ExpenseRowVM
            {
                Expense = e,
                ChargeCount = e.Charges.Count,
                PaidCount = e.Charges.Count(c => c.IsPaid),
                PaidSum = e.Charges.Where(c => c.IsPaid).Sum(c => c.Amount)
            }).ToListAsync();
        return View(rows);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");
        ViewBag.Building = b;
        return View(new ExpenseCreateVM());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ExpenseCreateVM vm)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var receiptError = ValidateReceipt(vm.Receipt);
        if (receiptError != null) ModelState.AddModelError(nameof(vm.Receipt), receiptError);

        List<(int Id, int Number, double? Area)> units = new();
        if (ModelState.IsValid)
        {
            var raw = await Db.Units.Where(u => u.BuildingId == b.Id)
                .OrderBy(u => u.Number).Select(u => new { u.Id, u.Number, u.Area }).ToListAsync();
            units = raw.Select(u => (u.Id, u.Number, u.Area)).ToList();

            if (units.Count == 0)
                ModelState.AddModelError("", "ساختمان هیچ واحدی ندارد");

            if (vm.SplitMethod == SplitMethod.ByArea)
            {
                var missing = units.Where(u => !u.Area.HasValue || u.Area <= 0).Select(u => u.Number).ToList();
                if (missing.Count > 0)
                    ModelState.AddModelError("", "متراژ این واحدها ثبت نشده است: " + string.Join("، ", missing) +
                        " — ابتدا از بخش «متراژ واحدها» آن‌ها را وارد کنید.");
            }
        }

        if (!ModelState.IsValid)
        {
            ViewBag.Building = b;
            return View(vm);
        }

        var total = vm.TotalAmount!.Value;
        var shares = CalculateShares(total, units, vm.SplitMethod);

        var expense = new Expense
        {
            BuildingId = b.Id,
            Title = vm.Title.Trim(),
            Description = vm.Description?.Trim(),
            TotalAmount = total,
            SplitMethod = vm.SplitMethod,
            PayerType = vm.PayerType
        };
        for (var i = 0; i < units.Count; i++)
            expense.Charges.Add(new Charge { UnitId = units[i].Id, Amount = shares[i] });

        if (vm.Receipt is { Length: > 0 })
            expense.ReceiptPath = await SaveReceiptAsync(vm.Receipt);

        Db.Expenses.Add(expense);
        await Db.SaveChangesAsync();

        TempData["Success"] = "هزینه ثبت و بین واحدها تقسیم شد.";
        return RedirectToAction(nameof(Details), new { id = expense.Id });
    }

    public async Task<IActionResult> Details(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var e = await Db.Expenses
            .Include(x => x.Charges).ThenInclude(c => c.Unit).ThenInclude(u => u.Resident)
            .FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (e == null) return NotFound();

        e.Charges = e.Charges.OrderBy(c => c.Unit.Number).ToList();
        return View(e);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> TogglePaid(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var c = await Db.Charges.Include(x => x.Expense)
            .FirstOrDefaultAsync(x => x.Id == id && x.Expense.BuildingId == b.Id);
        if (c == null) return NotFound();

        c.IsPaid = !c.IsPaid;
        c.PaidAt = c.IsPaid ? DateTime.Now : null;
        await Db.SaveChangesAsync();
        return RedirectToAction(nameof(Details), new { id = c.ExpenseId });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadReceipt(int id, IFormFile? receipt)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var e = await Db.Expenses.FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (e == null) return NotFound();

        if (receipt == null || receipt.Length == 0)
        {
            TempData["Error"] = "فایلی انتخاب نشده است.";
            return RedirectToAction(nameof(Details), new { id });
        }
        var error = ValidateReceipt(receipt);
        if (error != null)
        {
            TempData["Error"] = error;
            return RedirectToAction(nameof(Details), new { id });
        }

        var old = e.ReceiptPath;
        e.ReceiptPath = await SaveReceiptAsync(receipt);
        await Db.SaveChangesAsync();
        DeleteReceiptFile(old);

        TempData["Success"] = "فیش / فاکتور ذخیره شد.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> RemoveReceipt(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var e = await Db.Expenses.FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (e == null) return NotFound();

        var old = e.ReceiptPath;
        e.ReceiptPath = null;
        await Db.SaveChangesAsync();
        DeleteReceiptFile(old);

        TempData["Success"] = "فیش / فاکتور حذف شد.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var e = await Db.Expenses.FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (e == null) return NotFound();

        var old = e.ReceiptPath;
        Db.Expenses.Remove(e);
        await Db.SaveChangesAsync();
        DeleteReceiptFile(old);

        TempData["Success"] = "هزینه حذف شد.";
        return RedirectToAction(nameof(Index));
    }

    // ---------- کمکی‌ها ----------

    private static List<long> CalculateShares(long total, List<(int Id, int Number, double? Area)> units, SplitMethod method)
    {
        var shares = new List<long>();
        if (method == SplitMethod.ByArea)
        {
            var totalArea = units.Sum(u => (decimal)u.Area!.Value);
            foreach (var u in units)
                shares.Add((long)Math.Floor(total * (decimal)u.Area!.Value / totalArea));
        }
        else
        {
            var each = total / units.Count;
            foreach (var _ in units) shares.Add(each);
        }

        // باقیمانده ریز تقسیم (چند تومان) بین واحدهای اول پخش می‌شود تا جمع دقیقاً برابر مبلغ کل شود
        var remainder = total - shares.Sum();
        for (var i = 0; remainder > 0 && i < shares.Count; i++, remainder--)
            shares[i]++;

        return shares;
    }

    private static string? ValidateReceipt(IFormFile? file)
    {
        if (file == null || file.Length == 0) return null;
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExt.Contains(ext)) return "فرمت فایل مجاز نیست (فقط JPG، PNG، WEBP، GIF یا PDF).";
        if (file.Length > MaxReceiptBytes) return "حجم فایل نباید بیشتر از ۵ مگابایت باشد.";
        return null;
    }

    private string ReceiptsDir()
    {
        var root = env.WebRootPath ?? Path.Combine(env.ContentRootPath, "wwwroot");
        return Path.Combine(root, "uploads", "receipts");
    }

    private async Task<string> SaveReceiptAsync(IFormFile file)
    {
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var dir = ReceiptsDir();
        Directory.CreateDirectory(dir);
        var name = $"{Guid.NewGuid():N}{ext}";
        await using (var fs = new FileStream(Path.Combine(dir, name), FileMode.Create))
            await file.CopyToAsync(fs);
        return $"/uploads/receipts/{name}";
    }

    private void DeleteReceiptFile(string? path)
    {
        if (string.IsNullOrEmpty(path)) return;
        var full = Path.Combine(ReceiptsDir(), Path.GetFileName(path));
        if (System.IO.File.Exists(full)) System.IO.File.Delete(full);
    }
}
