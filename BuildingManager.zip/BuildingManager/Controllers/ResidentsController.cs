using BuildingManager.Data;
using BuildingManager.Helpers;
using BuildingManager.Models;
using BuildingManager.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Controllers;

[Authorize(Roles = Roles.Manager)]
public class ResidentsController(AppDbContext db) : AppController(db)
{
    public async Task<IActionResult> Index()
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        ViewBag.Building = b;
        var list = await Db.Residents.Include(r => r.Unit)
            .Where(r => r.BuildingId == b.Id).OrderBy(r => r.Unit.Number).ToListAsync();
        return View(list);
    }

    [HttpGet]
    public async Task<IActionResult> Create(int? unitId)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var vm = new ResidentCreateVM();
        if (unitId.HasValue) vm.UnitId = unitId.Value;
        await FillFormAsync(vm, b);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ResidentCreateVM vm)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        await ValidateCommonAsync(vm, b, null);

        var unit = await Db.Units.Include(u => u.Resident)
            .FirstOrDefaultAsync(u => u.Id == vm.UnitId && u.BuildingId == b.Id);
        if (unit == null)
            ModelState.AddModelError(nameof(vm.UnitId), "واحد انتخاب‌شده معتبر نیست");
        else if (unit.Resident != null)
            ModelState.AddModelError(nameof(vm.UnitId), "برای این واحد قبلاً ساکن ثبت شده است");

        var username = vm.Username.Trim().ToLowerInvariant();
        if (await Db.Users.AnyAsync(u => u.Username == username))
            ModelState.AddModelError(nameof(vm.Username), "این نام کاربری قبلاً استفاده شده است");

        if (!ModelState.IsValid)
        {
            await FillFormAsync(vm, b);
            return View(vm);
        }

        var resident = new Resident
        {
            BuildingId = b.Id,
            UnitId = unit!.Id,
            User = new AppUser
            {
                Username = username,
                FullName = vm.FullName.Trim(),
                PasswordHash = PasswordHelper.Hash(vm.Password),
                Role = Roles.Resident
            }
        };
        Apply(vm, resident);
        unit.Area = vm.Area;

        Db.Residents.Add(resident);
        await Db.SaveChangesAsync();

        TempData["NewUser"] = username;
        TempData["NewPass"] = vm.Password;
        return RedirectToAction(nameof(Details), new { id = resident.Id });
    }

    public async Task<IActionResult> Details(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var r = await Db.Residents.Include(x => x.Unit).Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (r == null) return NotFound();

        var unpaid = await Db.Charges.Include(c => c.Expense)
            .Where(c => c.UnitId == r.UnitId && !c.IsPaid).ToListAsync();
        ViewBag.Unpaid = unpaid.Where(c => ChargeRules.PayableBy(r, c.Expense)).Sum(c => c.Amount);
        ViewBag.OwnerUnpaid = unpaid.Where(c => !ChargeRules.PayableBy(r, c.Expense)).Sum(c => c.Amount);
        ViewBag.NewUser = TempData["NewUser"];
        ViewBag.NewPass = TempData["NewPass"];
        return View(r);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var r = await Db.Residents.Include(x => x.Unit)
            .FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (r == null) return NotFound();

        ViewBag.Building = b;
        ViewBag.UnitNumber = r.Unit.Number;
        return View(new ResidentFormVM
        {
            Id = r.Id, FullName = r.FullName, Phone = r.Phone, NationalId = r.NationalId,
            PersonCount = r.PersonCount, IsOwner = r.IsOwner, OwnerFullName = r.OwnerFullName,
            OwnerPhone = r.OwnerPhone, StorageNumber = r.StorageNumber, ParkingNumber = r.ParkingNumber,
            MoveInDate = r.MoveInDate, Notes = r.Notes, Area = r.Unit.Area
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ResidentFormVM vm)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var r = await Db.Residents.Include(x => x.Unit).Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (r == null) return NotFound();

        await ValidateCommonAsync(vm, b, r.Id);
        if (!ModelState.IsValid)
        {
            ViewBag.Building = b;
            ViewBag.UnitNumber = r.Unit.Number;
            return View(vm);
        }

        Apply(vm, r);
        r.Unit.Area = vm.Area;
        r.User.FullName = vm.FullName.Trim();
        await Db.SaveChangesAsync();

        TempData["Success"] = "مشخصات ساکن ذخیره شد.";
        return RedirectToAction(nameof(Details), new { id = r.Id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ResetPassword(int id, string? newPassword)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var r = await Db.Residents.Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (r == null) return NotFound();

        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 6)
        {
            TempData["Error"] = "رمز عبور جدید حداقل ۶ کاراکتر باشد.";
            return RedirectToAction(nameof(Details), new { id });
        }

        r.User.PasswordHash = PasswordHelper.Hash(newPassword);
        await Db.SaveChangesAsync();

        TempData["NewUser"] = r.User.Username;
        TempData["NewPass"] = newPassword;
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var b = await GetMyBuildingAsync();
        if (b == null) return RedirectToAction("Create", "Building");

        var r = await Db.Residents.Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Id == id && x.BuildingId == b.Id);
        if (r == null) return NotFound();

        Db.Users.Remove(r.User);
        Db.Residents.Remove(r);
        await Db.SaveChangesAsync();

        TempData["Success"] = "ساکن حذف شد و واحد خالی شد.";
        return RedirectToAction(nameof(Index));
    }

    // ---------- کمکی‌ها ----------

    private async Task FillFormAsync(ResidentCreateVM vm, Building b)
    {
        ViewBag.Building = b;
        var units = await Db.Units.Include(u => u.Resident)
            .Where(u => u.BuildingId == b.Id && u.Resident == null)
            .OrderBy(u => u.Number).ToListAsync();

        vm.Units = units.Select(u => new SelectListItem
        {
            Value = u.Id.ToString(),
            Text = $"واحد {u.Number} - طبقه {u.Floor}",
            Selected = u.Id == vm.UnitId
        }).ToList();
    }

    private async Task ValidateCommonAsync(ResidentFormVM vm, Building b, int? currentResidentId)
    {
        if (!vm.IsOwner && string.IsNullOrWhiteSpace(vm.OwnerFullName))
            ModelState.AddModelError(nameof(vm.OwnerFullName), "برای مستاجر، نام مالک را وارد کنید");

        if (vm.StorageNumber.HasValue)
        {
            if (vm.StorageNumber < 1 || vm.StorageNumber > b.StorageCount)
                ModelState.AddModelError(nameof(vm.StorageNumber), $"شماره انباری باید بین ۱ تا {b.StorageCount} باشد");
            else if (await Db.Residents.AnyAsync(r => r.BuildingId == b.Id && r.Id != currentResidentId && r.StorageNumber == vm.StorageNumber))
                ModelState.AddModelError(nameof(vm.StorageNumber), "این انباری به ساکن دیگری داده شده است");
        }

        if (vm.ParkingNumber.HasValue)
        {
            if (vm.ParkingNumber < 1 || vm.ParkingNumber > b.ParkingCount)
                ModelState.AddModelError(nameof(vm.ParkingNumber), $"شماره پارکینگ باید بین ۱ تا {b.ParkingCount} باشد");
            else if (await Db.Residents.AnyAsync(r => r.BuildingId == b.Id && r.Id != currentResidentId && r.ParkingNumber == vm.ParkingNumber))
                ModelState.AddModelError(nameof(vm.ParkingNumber), "این پارکینگ به ساکن دیگری داده شده است");
        }
    }

    private static void Apply(ResidentFormVM vm, Resident r)
    {
        r.FullName = vm.FullName.Trim();
        r.Phone = vm.Phone.Trim();
        r.NationalId = vm.NationalId?.Trim();
        r.PersonCount = vm.PersonCount ?? 1;
        r.IsOwner = vm.IsOwner;
        r.OwnerFullName = vm.IsOwner ? null : vm.OwnerFullName?.Trim();
        r.OwnerPhone = vm.IsOwner ? null : vm.OwnerPhone?.Trim();
        r.StorageNumber = vm.StorageNumber;
        r.ParkingNumber = vm.ParkingNumber;
        r.MoveInDate = vm.MoveInDate;
        r.Notes = vm.Notes?.Trim();
    }
}
