using BuildingManager.Models;
using Microsoft.AspNetCore.Mvc;

namespace BuildingManager.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        if (User.Identity?.IsAuthenticated == true)
        {
            if (User.IsInRole(Roles.Manager)) return RedirectToAction("Index", "Building");
            if (User.IsInRole(Roles.Resident)) return RedirectToAction("Index", "My");
        }
        return View();
    }

    public IActionResult Error() => View();
}
