using BuildingManager.Data;
using BuildingManager.Helpers;
using BuildingManager.Models;
using BuildingManager.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Controllers;

[Authorize(Roles = Roles.Resident)]
public class MyController(AppDbContext db) : AppController(db)
{
    private Task<Resident?> GetResidentAsync()
        => Db.Residents.Include(r => r.Unit).Include(r => r.Building)
            .FirstOrDefaultAsync(r => r.UserId == UserId);

    public async Task<IActionResult> Index()
    {
        var r = await GetResidentAsync();
        if (r == null) return Forbid();

        var all = await Db.Charges.Include(c => c.Expense)
            .Where(c => c.UnitId == r.UnitId)
            .OrderByDescending(c => c.Expense.CreatedAt).ToListAsync();

        var mine = all.Where(c => ChargeRules.PayableBy(r, c.Expense)).ToList();
        var ownerOnes = all.Where(c => !ChargeRules.PayableBy(r, c.Expense)).ToList();

        return View(new MyIndexVM
        {
            Resident = r,
            Charges = mine,
            OwnerCharges = ownerOnes,
            UnpaidTotal = mine.Where(c => !c.IsPaid).Sum(c => c.Amount),
            PaidTotal = mine.Where(c => c.IsPaid).Sum(c => c.Amount)
        });
    }

    // صفحه پرداخت: id خالی = پرداخت همه هزینه‌های باقی‌مانده
    [HttpGet]
    public async Task<IActionResult> Pay(int? id)
    {
        var r = await GetResidentAsync();
        if (r == null) return Forbid();

        var list = await GetPayableUnpaidAsync(r, id);
        if (list.Count == 0)
        {
            TempData["Error"] = "هزینه پرداخت‌نشده‌ای برای پرداخت وجود ندارد.";
            return RedirectToAction(nameof(Index));
        }

        var manager = await Db.Users.FirstAsync(u => u.Id == r.Building.ManagerId);
        return View(new PayVM
        {
            Title = list.Count == 1 ? list[0].Expense.Title : $"همه هزینه‌های باقی‌مانده ({list.Count} مورد)",
            Amount = list.Sum(c => c.Amount),
            CardNumber = manager.CardNumber,
            CardHolderName = manager.CardHolderName,
            ManagerName = manager.FullName,
            ChargeId = id
        });
    }

    // ساکن بعد از واریز، پرداخت را تأیید می‌کند (مدیر هم می‌تواند در صورت اشتباه وضعیت را برگرداند)
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ConfirmPay(int? id)
    {
        var r = await GetResidentAsync();
        if (r == null) return Forbid();

        var list = await GetPayableUnpaidAsync(r, id);
        foreach (var c in list)
        {
            c.IsPaid = true;
            c.PaidAt = DateTime.Now;
        }
        await Db.SaveChangesAsync();

        TempData["Success"] = list.Count > 0 ? "پرداخت شما ثبت شد. ممنون!" : "هزینه پرداخت‌نشده‌ای وجود ندارد.";
        return RedirectToAction(nameof(Index));
    }

    private async Task<List<Charge>> GetPayableUnpaidAsync(Resident r, int? chargeId)
    {
        var q = Db.Charges.Include(c => c.Expense).Where(c => c.UnitId == r.UnitId && !c.IsPaid);
        if (chargeId.HasValue) q = q.Where(c => c.Id == chargeId.Value);
        var list = await q.ToListAsync();
        return list.Where(c => ChargeRules.PayableBy(r, c.Expense)).ToList();
    }
}
