using System.ComponentModel.DataAnnotations;
using BuildingManager.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BuildingManager.ViewModels;

public class RegisterVM
{
    [Required(ErrorMessage = "نام و نام خانوادگی را وارد کنید")]
    [MaxLength(100)]
    [Display(Name = "نام و نام خانوادگی")]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "نام کاربری را وارد کنید")]
    [StringLength(30, MinimumLength = 3, ErrorMessage = "نام کاربری باید بین ۳ تا ۳۰ حرف باشد")]
    [RegularExpression("^[a-zA-Z0-9_.]+$", ErrorMessage = "نام کاربری فقط شامل حروف انگلیسی، عدد، _ و . باشد")]
    [Display(Name = "نام کاربری (انگلیسی)")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "رمز عبور را وارد کنید")]
    [MinLength(6, ErrorMessage = "رمز عبور حداقل ۶ کاراکتر باشد")]
    [DataType(DataType.Password)]
    [Display(Name = "رمز عبور")]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "تکرار رمز عبور را وارد کنید")]
    [Compare(nameof(Password), ErrorMessage = "رمز عبور و تکرار آن یکسان نیست")]
    [DataType(DataType.Password)]
    [Display(Name = "تکرار رمز عبور")]
    public string ConfirmPassword { get; set; } = "";

    [Required(ErrorMessage = "شماره کارت را وارد کنید")]
    [Display(Name = "شماره کارت برای دریافت هزینه‌ها (۱۶ رقم)")]
    public string CardNumber { get; set; } = "";

    [MaxLength(100)]
    [Display(Name = "نام صاحب کارت")]
    public string? CardHolderName { get; set; }
}

public class LoginVM
{
    [Required(ErrorMessage = "نام کاربری را وارد کنید")]
    [Display(Name = "نام کاربری")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "رمز عبور را وارد کنید")]
    [DataType(DataType.Password)]
    [Display(Name = "رمز عبور")]
    public string Password { get; set; } = "";

    [Display(Name = "مرا به خاطر بسپار")]
    public bool RememberMe { get; set; } = true;

    public string? ReturnUrl { get; set; }
}

public class BuildingCreateVM
{
    [Required(ErrorMessage = "نام ساختمان را وارد کنید")]
    [MaxLength(150)]
    [Display(Name = "نام ساختمان")]
    public string Name { get; set; } = "";

    [MaxLength(300)]
    [Display(Name = "آدرس")]
    public string? Address { get; set; }

    [Required(ErrorMessage = "تعداد طبقات را وارد کنید")]
    [Range(1, 60, ErrorMessage = "تعداد طبقات بین ۱ تا ۶۰ باشد")]
    [Display(Name = "تعداد طبقات")]
    public int? FloorsCount { get; set; }

    [Required(ErrorMessage = "تعداد واحد در هر طبقه را وارد کنید")]
    [Range(1, 20, ErrorMessage = "تعداد واحد در هر طبقه بین ۱ تا ۲۰ باشد")]
    [Display(Name = "تعداد واحد در هر طبقه")]
    public int? UnitsPerFloor { get; set; }

    [Range(0, 500, ErrorMessage = "عدد معتبر وارد کنید")]
    [Display(Name = "تعداد انباری")]
    public int StorageCount { get; set; }

    [Range(0, 500, ErrorMessage = "عدد معتبر وارد کنید")]
    [Display(Name = "تعداد پارکینگ")]
    public int ParkingCount { get; set; }
}

public class BuildingEditVM
{
    [Required(ErrorMessage = "نام ساختمان را وارد کنید")]
    [MaxLength(150)]
    [Display(Name = "نام ساختمان")]
    public string Name { get; set; } = "";

    [MaxLength(300)]
    [Display(Name = "آدرس")]
    public string? Address { get; set; }

    [Range(0, 500, ErrorMessage = "عدد معتبر وارد کنید")]
    [Display(Name = "تعداد انباری")]
    public int StorageCount { get; set; }

    [Range(0, 500, ErrorMessage = "عدد معتبر وارد کنید")]
    [Display(Name = "تعداد پارکینگ")]
    public int ParkingCount { get; set; }
}

public class DashboardVM
{
    public Building Building { get; set; } = null!;
    public int ResidentCount { get; set; }
    public int EmptyUnits { get; set; }
    public int ExpenseCount { get; set; }
    public long UnpaidTotal { get; set; }
    public long PaidTotal { get; set; }
    public List<Expense> RecentExpenses { get; set; } = new();
}

public class ResidentFormVM
{
    public int Id { get; set; }

    [Required(ErrorMessage = "نام و نام خانوادگی را وارد کنید")]
    [MaxLength(100)]
    [Display(Name = "نام و نام خانوادگی ساکن")]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "شماره تماس را وارد کنید")]
    [MaxLength(20)]
    [Display(Name = "شماره تماس")]
    public string Phone { get; set; } = "";

    [MaxLength(20)]
    [Display(Name = "کد ملی")]
    public string? NationalId { get; set; }

    [Required(ErrorMessage = "تعداد نفرات را وارد کنید")]
    [Range(1, 30, ErrorMessage = "تعداد نفرات بین ۱ تا ۳۰ باشد")]
    [Display(Name = "تعداد نفرات ساکن")]
    public int? PersonCount { get; set; } = 1;

    [Required(ErrorMessage = "متراژ واحد را وارد کنید")]
    [Range(5, 5000, ErrorMessage = "متراژ معتبر وارد کنید")]
    [Display(Name = "متراژ واحد (متر مربع)")]
    public double? Area { get; set; }

    [Display(Name = "وضعیت سکونت")]
    public bool IsOwner { get; set; } = true;

    [MaxLength(100)]
    [Display(Name = "نام و نام خانوادگی مالک")]
    public string? OwnerFullName { get; set; }

    [MaxLength(20)]
    [Display(Name = "شماره تماس مالک")]
    public string? OwnerPhone { get; set; }

    [Display(Name = "شماره انباری")]
    public int? StorageNumber { get; set; }

    [Display(Name = "شماره پارکینگ")]
    public int? ParkingNumber { get; set; }

    [Display(Name = "تاریخ ورود")]
    [DataType(DataType.Date)]
    public DateTime? MoveInDate { get; set; }

    [MaxLength(500)]
    [Display(Name = "توضیحات")]
    public string? Notes { get; set; }
}

public class ResidentCreateVM : ResidentFormVM
{
    [Range(1, int.MaxValue, ErrorMessage = "واحد را انتخاب کنید")]
    [Display(Name = "واحد")]
    public int UnitId { get; set; }

    [Required(ErrorMessage = "نام کاربری را وارد کنید")]
    [StringLength(30, MinimumLength = 3, ErrorMessage = "نام کاربری باید بین ۳ تا ۳۰ حرف باشد")]
    [RegularExpression("^[a-zA-Z0-9_.]+$", ErrorMessage = "نام کاربری فقط شامل حروف انگلیسی، عدد، _ و . باشد")]
    [Display(Name = "نام کاربری ساکن (انگلیسی)")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "رمز عبور را وارد کنید")]
    [MinLength(6, ErrorMessage = "رمز عبور حداقل ۶ کاراکتر باشد")]
    [Display(Name = "رمز عبور ساکن")]
    public string Password { get; set; } = "";

    [ValidateNever]
    public List<SelectListItem> Units { get; set; } = new();
}

public class ExpenseCreateVM
{
    [Required(ErrorMessage = "عنوان هزینه را وارد کنید")]
    [MaxLength(150)]
    [Display(Name = "عنوان هزینه")]
    public string Title { get; set; } = "";

    [Required(ErrorMessage = "مبلغ کل را وارد کنید")]
    [Range(1, 100_000_000_000, ErrorMessage = "مبلغ معتبر وارد کنید")]
    [Display(Name = "مبلغ کل (تومان)")]
    public long? TotalAmount { get; set; }

    [MaxLength(1000)]
    [Display(Name = "توضیحات (برای همه ساکنین نمایش داده می‌شود)")]
    public string? Description { get; set; }

    [Display(Name = "روش تقسیم")]
    public SplitMethod SplitMethod { get; set; } = SplitMethod.Equal;

    [Display(Name = "پرداخت‌کننده")]
    public PayerType PayerType { get; set; } = PayerType.Occupant;

    [Display(Name = "عکس فیش / فاکتور (اختیاری)")]
    public IFormFile? Receipt { get; set; }
}

public class ExpenseRowVM
{
    public Expense Expense { get; set; } = null!;
    public int ChargeCount { get; set; }
    public int PaidCount { get; set; }
    public long PaidSum { get; set; }
}

public class MyIndexVM
{
    public Resident Resident { get; set; } = null!;
    public List<Charge> Charges { get; set; } = new();
    public List<Charge> OwnerCharges { get; set; } = new();
    public long UnpaidTotal { get; set; }
    public long PaidTotal { get; set; }
}

public class ProfileVM
{
    [MaxLength(100)]
    [Display(Name = "نام و نام خانوادگی")]
    public string? FullName { get; set; }

    [Required(ErrorMessage = "نام کاربری را وارد کنید")]
    [StringLength(30, MinimumLength = 3, ErrorMessage = "نام کاربری باید بین ۳ تا ۳۰ حرف باشد")]
    [RegularExpression("^[a-zA-Z0-9_.]+$", ErrorMessage = "نام کاربری فقط شامل حروف انگلیسی، عدد، _ و . باشد")]
    [Display(Name = "نام کاربری")]
    public string Username { get; set; } = "";

    [Display(Name = "شماره کارت (۱۶ رقم)")]
    public string? CardNumber { get; set; }

    [MaxLength(100)]
    [Display(Name = "نام صاحب کارت")]
    public string? CardHolderName { get; set; }

    public bool IsManager { get; set; }
}

public class UnitAreaVM
{
    public int Id { get; set; }
    public int Number { get; set; }
    public int Floor { get; set; }
    public string? ResidentName { get; set; }

    [Range(5, 5000, ErrorMessage = "متراژ معتبر وارد کنید")]
    public double? Area { get; set; }
}

public class PayVM
{
    public string Title { get; set; } = "";
    public long Amount { get; set; }
    public string? CardNumber { get; set; }
    public string? CardHolderName { get; set; }
    public string ManagerName { get; set; } = "";
    public int? ChargeId { get; set; }
}
