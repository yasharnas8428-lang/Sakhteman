# راه‌اندازی روی سرور داخل ایران (کار با اینترنت ملی)

برای اینکه برنامه با اینترنت ملی (بدون VPN) باز شود، سرور باید داخل ایران باشد.
هاست یا VPS از شرکت‌های ایرانی بگیرید (مثل آروان‌کلود، ایران‌سرور، پارس‌پک و ...).
Dev Tunnels و Cloudflare Tunnel روی اینترنت ملی کار نمی‌کنند.

## قدم ۱: یک‌بار روی کامپیوتر خودتان (با اینترنت آزاد/VPN)
1. پروژه را باز کنید و یک بار F5 بزنید. فایل‌های بوت‌استرپ و فونت داخل wwwroot/lib دانلود می‌شوند.
   (اگر دانلود نشد: wwwroot/lib/README.txt را ببینید.)
2. بررسی کنید پوشه BuildingManager/wwwroot/lib پر شده باشد.

## قدم ۲: ساخت نسخه نهایی (Publish)
در پوشه‌ای که BuildingManager.sln هست، Command Prompt باز کنید:

برای سرور ویندوز:
    dotnet publish BuildingManager\BuildingManager.csproj -c Release -r win-x64 --self-contained true -o publish

برای سرور لینوکس:
    dotnet publish BuildingManager/BuildingManager.csproj -c Release -r linux-x64 --self-contained true -o publish

(self-contained یعنی نیازی به نصب .NET روی سرور نیست؛ مناسب سرور بدون اینترنت جهانی.)

## قدم ۳: اجرا روی سرور
محتوای پوشه publish را روی سرور کپی کنید.

ویندوز (در Command Prompt سرور):
    BuildingManager.exe --urls http://0.0.0.0:80
و پورت 80 را در Firewall باز کنید:
    netsh advfirewall firewall add rule name="BuildingManager" dir=in action=allow protocol=TCP localport=80
برای اجرای خودکار بعد از ریستارت: Task Scheduler ← Create Task ← Trigger: At startup ← Action: همان فایل با آرگومان بالا.

لینوکس:
    chmod +x BuildingManager
    ./BuildingManager --urls http://0.0.0.0:80
(برای اجرای دائمی از systemd یا screen/tmux استفاده کنید.)

بعد، گوشی (با اینترنت ملی) آدرس http://IP-سرور را باید باز کند.

## نکات مهم
- دیتابیس: فایل BuildingManager.db کنار برنامه؛ فیش‌ها: wwwroot/uploads/receipts. این‌ها را در به‌روزرسانی پاک نکنید و گاهی از آن‌ها پشتیبان بگیرید.
- اگر سرور دامنه و SSL دارد از https://... استفاده کنید (امن‌تر). اپ اندروید هر دو را پشتیبانی می‌کند.
- رمزها در HTTP ساده رمزنگاری نمی‌شوند؛ اگر امکانش هست SSL فعال کنید.
